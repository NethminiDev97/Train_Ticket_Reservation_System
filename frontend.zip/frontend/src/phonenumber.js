import React,{Component} from 'react';
import ReactDOM from "react-dom";
import App from "./App";
import Register from './Register';

export default class phonenumber extends Component{
    constructor(props){
        super(props);
        this.state={
            Number:this.props.Number,
            amount:this.props.amount,
            pin:this.props.pin,

        }
    }
    //send details to the back end
    home=function(Number,amount,pin) {

        var subTotal = parseFloat(this.state.subtot);

        var data = {"Number": this.state.Number, "amount": amount, "pin": pin};
        fetch('http://localhost:3001/dialogpay/', {
            method: 'POST',
            body: JSON.stringify(data),
            headers: {'Content-Type': 'application/json'}
        }).then(response => {
            return response.json();
        }).then(data => {
            console.log(data);
        }).catch(err => {
            alert("ERRRTT " + err);
        })
    }
        back(){
            ReactDOM.render(<App name={this.state.name}
                                 email={this.state.email}/>, document.getElementById('root'));
        }
    handleNumberChange=(event)=>{
        this.setState({
            Number:event.target.value
        })
    }
    handleamountChange=(event)=>{
        this.setState({
            amount:event.target.value
        })
    }
    handlepinChange=(event)=>{
        this.setState({
            pin:event.target.value
        })
    }


    render() {

        return (
//Dialog payment interface
            <div>
                <br></br>
                <form>
                    <table>
                        <tr>
                            <td>
                                Number
                            </td>

                            <input type='text' value={this.state.Number}
                                   onChange={this.handleNumberChange}/>
                        </tr>
                        <br></br>
                        <tr>
                            <td>
                                Amount
                            </td>
                            <input type='number' value={this.state.amount}
                                   onChange={this.handleamountChange}/>
                        </tr>
                        <br></br>
                        <tr>

                            <td>pin number</td>
                            <input type='number' value={this.state.pin}
                                   onChange={this.handlepinChange}/>

                        </tr>

                        <br></br>
                        <br></br>

                        <input type="submit" value="Submit"/>
                    </table>
                </form>
            </div>
        )
    }



    }