import React,{Component} from 'react';
import Bar from "./Bar";
import logo from "./2.jpg";
import FormGroup from "reactstrap/es/FormGroup";
//import {Link} from 'react-router-dom';
//import {Jumbotron, Grid ,Row, Col, Image, Button} from 'react-bootstrap';
//import './Home.css';

export default class Home extends Component{

    render(){

        return(
            <div>
            <h1>Travels</h1>
                <Bar/>
                <h2>Welcome to the travels train ticket reservation.</h2>
                    <h3>Before you logging to the system to book a ticket, you must register to
                    the system</h3>
                <p text-align="left" HSPACE="80" >
                    Greate chance to people who are unable to come on time to the train because of the traffic problems and other reasons.
                    So they can book a ticket by using our web application without coming to the station early.

                </p>
                <img src ={logo} alt="2" align="center" HSPACE="100"
                     height={400}
                     wdith={1000}
                />



            </div>

        )


    }
}
