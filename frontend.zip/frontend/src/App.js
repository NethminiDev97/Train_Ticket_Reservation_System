
import React, { Component } from 'react';

import './App.css';
//import search from './search';

import Register from "./Register";
import Booking from "./Booking";
import Home from "./Home";
import TrainTicketInfo from "./TrainTicketInfo";
import {BrowserRouter, Link} from "react-router-dom";
import {Redirect, Route, Switch, withRouter} from "react-router";
//import AboutUs from "components/AboutUs";
import ReactDOM from "react-dom";

class App extends Component {
  render() {
    return (

        <div className="App">
            <BrowserRouter>


                    <Switch>
                        <Route exact path="/" component={Home}/>
                        <Route path="/Booking" component={Booking}/>
                        <Route path="/Register" component={Register}/>
                        <Route path="/TrainTicketInfo" component={TrainTicketInfo}/>
                        <Route component={Home}/>

                    </Switch>

            </BrowserRouter>



        </div>
    );
  }
}

export default App;
