import React,{Component} from 'react';
import {BrowserRouter, NavLink, Route, Switch} from "react-router-dom";
import ButtonToolbar from "reactstrap/es/ButtonToolbar";
import Register from "./Register";
import Bar from "./Bar";
import logo from "./2.jpg";
import ReactDOM from "react-dom";
import Home from "./Home";
import TrainTicketInfo from "./TrainTicketInfo";
import creditcard from "./creditcard";
import phonenumber from "./phonenumber";
export default class Booking extends Component{
    constructor(props){
        super(props)
        this.state={
            name:'',
            destination:'destination',
            payment:'payment',
            No:''
        }
    }
    handleUsernameChange=(event)=>{
        this.setState({
            username:event.target.value
        })
    }
    handleTopicChange=event=>{
        this.setState({
            Destination:event.target.value
        })
    }
    handleTopicChange=event=>{
        this.setState({
            Payment:event.target.value
        })
    }
    handleTicketsChange=event=>{
        this.setState({
            No:event.target.value
        })
    }
//this method is called when submit button will click
    signup(){
        const name=this.refs.name.value;
        const destination=this.refs.destination.value;
        const password=this.refs.password.value;
        const email=this.refs.email.value;
        const NoOfTickets=this.refs.NoOfTickets.value;
        const paymentMethod=this.refs.paymentMethod.value;

//if any filed is empty,an alert is displayed
        if(name==''||destination==''||password==''||email==''||NoOfTickets==''||paymentMethod==''){
            alert('One or more fields empty');
        }
        else{
            var foundemail=false;
            fetch('http://localhost:3001/user/' + email, {
                method: 'GET',
                headers: {'Content-Type': 'application/json'}
            }).then(response => {
                return response.json();
            }).then(data => {
                var user = JSON.stringify(data);
                console.log(user);
                if (user != '[]') {
                    alert('Email is already in use');
                }
                else{
//if the entered email is not already in se registers the user an directs the user to the login page
                    var data={"name":name,"destination":destination,"password":password,"email":email,"NoOfTickets":NoOfTickets,"paymentMethod":paymentMethod};
                    console.log(data);
                    fetch('http://localhost:3001/user/', {
                        method: 'POST',
                        body:JSON.stringify(data),
                        headers: {'Content-Type': 'application/json'}
                    }).then(response => {
                        return response.json();
                    }).then(data => {
                        alert('Successful Sign Up');
                        ReactDOM.render(<Register/>,
                            document.getElementById('root'));
                    }).catch(err => {
                        alert("Second "+err);
                    })                 }


            }).catch(err => {
                alert("First Err: "+err);
            })
        }
    }
    Register(){
        ReactDOM.render(<Register/>,document.getElementById('root'));
    }

    //if you clicks on the card payment method the credit card component is rendered
    getCardPay=function(tot){
        ReactDOM.render(<creditcard email={this.state.email}
                                    name={this.state.name} amount={this.state.amount}/>,
            document.getElementById('root'));
    }
    // dialogPay=function(tot){
    //     ReactDOM.render(<DialogPay total={tot} name={this.state.name}
    //                                points={this.state.points} email={this.state.email}/>,
    //         document.getElementById('root'));
    // }



    render(){

        return(

            <div>
                <h1>Travels</h1>

                <br></br>
                <Bar/>

                <br></br>
                <img src={logo} alt="2" align="left" hspace="50"
                     height={500}
                     wdith={1000}
                />
                <br></br>

                <form>

                    <table align="middle" hspace="50">
                        <tr>
                            <td>
                                    Name
                            </td>

                                <input type='text' value={this.state.username}
                                       onChange={this.handleUsernameChange}/>
                        </tr>
                        <br></br>
                        <tr>
                            <td>
                                Destination

                            </td>
                            <select value={this.state.Destination} onChange={this.handleTopicChange}>
                                <option value="Colombo-Kandy">ColomboKandy</option>
                                <option value="Colombo-Badulla">ColomboBadulla</option>
                                <option value="Colombo-Jaffna">ColomboJaffna</option>
                                <option value="Colombo-Matara">ColomboMatara</option>
                            </select>

                        </tr>
                        <br></br>
                        <tr>

                                <td>Password </td>
                                <input type='password' value={this.state.password}
                                       onChange={this.handlePasswordChange}/>

                        </tr>
                        <br></br>
                        <br></br>
                        <tr>
                            <td>
                                Email
                            </td>

                            <input type='text' value={this.state.No}
                                   onChange={this.handleTicketsChange}/>
                        </tr>
                        <br></br>
                        <br></br>
                        <tr>
                            <td>
                                No of tickets
                            </td>

                            <input type='number' value={this.state.No}
                                   onChange={this.handleTicketsChange}/>
                        </tr>
                        <br></br>
                        <br></br>
                            <tr>
                                <td>
                                    Payment Method
                                </td>

                                <select value={this.state.Payment} onChange={this.handleTopicChange}>
                                    <option value="Mobile Number">Mobile Number</option>
                                    <option value="Credit Card">Credit Card</option>

                                </select>
                            </tr>
                        <br></br>
                        <input type="submit"  value="Phone Number"/>
                        <input type="submit"  value="Credit Card  "/>
                            <br></br>
                            <br></br>

                        <input type="submit"  value="Submit"/>

                    </table>

                </form>

            </div>
        )
    }
}