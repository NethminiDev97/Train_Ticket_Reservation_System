import React,{Component} from 'react';
import ReactDOM from "react-dom";
import App from "./App";
import Register from './Register';
import logo from "./2.jpg";
export default class creditcard extends Component{

    constructor(props){
        super();
        this.state= {
            email:this.props.email,
            name:this.props.name,
            cardNumber:this.props.cardNumber,
            cvc:this.props.cvc,
            amount:this.props.amount,

        }
    }
    home=function(email,name,cardNumber,cvc,amount) {
        console.log(email + "--" + name + "--" + cardNumber + "--" + cvc + "--" + amount);


        var data = {"email": this.state.email, "name": name, "cardNumber": cardNumber, "cvc": cvc, "amount": amount};
        fetch('http://localhost:3001/creditcard/', {
            method: 'POST',
            body: JSON.stringify(data),
            headers: {'Content-Type': 'application/json'}
        }).then(response => {
            return response.json();
        }).then(data => {
            console.log(data);
        }).catch(err => {
            alert("ERRRTT " + err);
        })
    }
        back(){
            ReactDOM.render(<App name={this.state.name} points={this.state.points}
                                 email={this.state.email}/>, document.getElementById('root'));
        }
    handleEmailChange=(event)=>{
        this.setState({
            email:event.target.value
        })
    }
    handlenameChange=(event)=>{
        this.setState({
            name:event.target.value
        })
    }
    handlecardNumberChange=(event)=>{
        this.setState({
            cardNumber:event.target.value
        })
    }
    handlecvcChange=(event)=>{
        this.setState({
            cvc:event.target.value
        })
    }
    handleamountChange=(event)=>{
        this.setState({
            amount:event.target.value
        })
    }




        render(){
            
            return(
//sampath payment interface
                <div>
                <br></br>
                <form>
                    <table>
                <tr>
                    <td>
                        Email
                    </td>

            <input type='text' value={this.state.email}
                   onChange={this.handleEmailChange}/>
            </tr>
            <br></br>
            <tr>
                <td>
                    Name
                </td>
                <input type='text' value={this.state.name}
                       onChange={this.handlenameChange}/>
            </tr>
            <br></br>
            <tr>

            <td>cardNumber </td>
            <input type='number' value={this.state.cardNumber}
                   onChange={this.handlecardNumberChange}/>

            </tr>
                    <br></br>
                    <tr>

                        <td>cvc Number </td>
                        <input type='number' value={this.state.cvc}
                               onChange={this.handlecvcChange}/>

                    </tr>
                    <br></br>
                    <tr>

                        <td>Amount </td>
                        <input type='number' value={this.state.amount}
                               onChange={this.handleamountChange}/>

                    </tr>
                        <br></br>
                        <br></br>

                        <input type="submit"  value="Submit"/>
                    </table>
                </form>
                </div>
            
            
            )
                    

        
    }

    }