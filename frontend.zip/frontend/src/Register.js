import React,{Component} from 'react';
import logo from './2.jpg';
import Bar from "./Bar";
import Booking from "./Booking"
import ReactDom from 'react-dom';
import './App.css';
import App from "./App";
export default class Register extends Component{
    constructor(props){
        super(props)
        this.state={
            email:'',
            password:''
        }
    }
    handleEmailChange=(event)=>{
        this.setState({
            email:event.target.value
        })
    }
    handlePasswordChange=(event)=>{
        this.setState({
            password:event.target.value
        })
    }
//this checks user credintials are valid or invalid
    toggle=function(e){
        const email=this.refs.email.value;
        const password=this.refs.password.value;

        if(email==='' || password===''){
            alert('Email or Password Empty');
        }

        else {
            var credentials = {"email": email, "password": password};
            var count = false;

            //calls the backend server which would route this request to the class which handles all request based on the user table
            fetch('http://localhost:3001/user/' + credentials.email + '/' +
                credentials.password, {
                method: 'GET',
                headers: {'Content-Type': 'application/json'}
            }).then(response => {
                return response.json();
            }).then(data => {
                var user = JSON.stringify(data);
                if (user != '[]') {
                    console.log(user);
                    count = true;
                    console.log(data);
                    for(var user of data){
                        var name=user.name;
                        var points=user.loyaltypoints;
                    }
                    ReactDom.render(<App name={name} points={points}
                                         email={email}/>, document.getElementById('root'));
                }                 else {
                    alert("Invalid username or password");
                }
            }).catch(err => {
                alert(err);
            })
            if (count == true) {
                ReactDom.render(<App/>, document.getElementById('root'));
            }
        else {
            ReactDom.render(<Register/>, document.getElementById('root'));
        }
        }
    }
    //when submit  button is clicked this method is called and it renders the Booking component

Booking(){
        ReactDom.render(<Booking/>,document.getElementById('root'));
}

render(){

        return(
            <div>
                <h1>Travels</h1>

                <br></br>
                <Bar/>
                <br></br>
                <img src={logo} alt="2" align="left" hspace="50"
                     height={500}
                     wdith={1000}
                />
                <br></br>
                <form >
                    <table align="middle" hspace="50" >
                        <tr>
                    <div>
                            <td>  Email </td>
                            <input type='text' value={this.state.email}
                               onChange={this.handleEmailChange}/>
                    </div>
                        </tr>

                        <br></br>
                        <tr>
                            <div>
                                <td>Password </td>
                                <input type='password' value={this.state.password}
                                       onChange={this.handlePasswordChange}/>
                            </div>
                        </tr>

                        <br></br>

                        <button type="submit"> Submit</button>

                    </table>
                </form>

            </div>
        )
    }
}