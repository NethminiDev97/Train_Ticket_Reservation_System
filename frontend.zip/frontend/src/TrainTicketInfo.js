import React,{Component} from 'react';
import Bar from "./Bar";
import logo from "./2.jpg";
export default class TrainTicketInfo extends Component{
    render(){

        return(
            <div>
                <h1>Travels</h1>

                <br></br>
                <Bar/>
                <br></br>
                <img src={logo} alt="2" align="left" hspace="50"
                     height={500}
                     wdith={1000}
                />
                <h1>Available Distinations</h1>
                <p>Colombo-Kandy</p>
                <p> Colombo-Badulla</p>
                <p> Colombo-Jaffna</p>
                <p>Colombo-Matara</p>

                <h1>Additional Details</h1>
                <h2>Terms and Conditions</h2>

                <p>No cancellation and no refund policy apply and standard customer verifications and other terms and conditions apply</p>



            </div>
        )
    }
}