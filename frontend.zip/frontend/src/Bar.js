import React,{Component} from 'react';


import Home from "./Home";

import Register from "./Register";
import Booking from "./Booking";
import TrainTicketInfo from "./TrainTicketInfo";
import {NavLink} from "react-router-dom";

export default class Bar extends Component {
    render() {

        return (
            <div>
            <table width="50">
                <tr>
                    <th colSpan="290">

                        <NavLink to="/Home">

                            <button className="btn btn-primary" type="submit" >Home

                            </button>
                        </NavLink>
                    </th>
                    <th colSpan="100">

                        <NavLink to="/TrainTicketInfo">

                            <button className="btn btn-primary" type="submit" >TrainTicketInfo

                            </button>
                        </NavLink>
                    </th>

                    <th colSpan="200">

                        <NavLink to="/Booking">

                            <button className="btn btn-primary" type="submit" >Booking

                            </button>
                        </NavLink>
                    </th>
                    <th colSpan="350">

                        <NavLink to="/Register">

                            <button className="btn btn-primary" type="submit" >Register

                            </button>
                        </NavLink>
                    </th>
                </tr>
            </table>

</div>)

    }
}


